/** @format */

import React, { Component } from 'react';
import SearchMovies from '../serch/SearchMovies';

export class User extends Component {
	constructor(props) {}
	render() {
		return (
			<div>
				<SearchMovies />
			</div>
		);
	}
}

export default User;
